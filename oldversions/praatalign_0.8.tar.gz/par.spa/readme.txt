Found at:
http://www.phon.ucl.ac.uk/home/sampa/spanish.htm

Symbol   Word    Transcription
--Consonants:
 -plosives
p        padre   "paDre
b        vino    "bino
t        tomo    "tomo
d        donde   "donde
k        casa    "kasa
g        gata     "gata
 -affricates
tS        mucho  "mutSo
jj        hielo  "jjelo
 -fricatives
f        fácil   "faTil
B        cabra   "kaBra   (= /b/)
T        cinco   "Tinko
D        nada    "naDa    (= /d/)
s        sala    "sala
x        mujer   mu"xer
G        luego   "lweGo   (= /g/)
 -nasals
m        mismo   "mismo
n        nunca   "nunka
J        año     "aJo
 -liquids
l        lejos   "lexos
L        caballo  ka"baLo (or as jj)
r        puro    "puro
rr        torre  "torre
 -semivowels
j        rei      rrej
         pie      pje
w        deuda    "dewDa
        muy       mwi
--Vowels:
i        pico    "piko
e        pero    "pero
a        valle   "baLe
o        toro    "toro
u        duro    "duro
